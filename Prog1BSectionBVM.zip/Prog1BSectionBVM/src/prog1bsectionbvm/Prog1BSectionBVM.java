
package prog1bsectionbvm;

import java.util.ArrayList;
import java.util.Scanner;

public class Prog1BSectionBVM {
    private static ArrayList<Employee> employees = new ArrayList<Employee>();
    private static int nextId = 1;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean running = true;
        
        while (running) {
            System.out.println("\n=== Employee Payroll System ===");
            System.out.println("1. Add Employees and Calculate Payroll");
            System.out.println("2. Delete an Employee");
            System.out.println("3. Show Employee Reports");
            System.out.println("4. Exit");
            System.out.print("Please choose an option (1-4): ");
            
            String input = scanner.nextLine().trim();
            
            if (isValidInteger(input)) {
                int choice = Integer.parseInt(input);
                
                switch (choice) {
                    case 1:
                        addEmployees();
                        break;
                    case 2:
                        deleteEmployee();
                        break;
                    case 3:
                        showReports();
                        break;
                    case 4:
                        running = false;
                        System.out.println("Thank you for using the Employee Payroll System. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid option. Please choose a number between 1 and 4.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number between 1 and 4.");
            }
        }
        
        scanner.close();
    }

    // Helper method to check if a string is a valid integer
    private static boolean isValidInteger(String input) {
        if (input == null || input.isEmpty()) {
            return false;
        }
        
        for (char c : input.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        
        return true;
    }
    
    // Helper method to check if a string is a valid double
    private static boolean isValidDouble(String input) { //(OpenAI,2023)
        if (input == null || input.isEmpty()) {
            return false;
        }
        
        boolean decimalFound = false;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            
            if (i == 0 && c == '-') {
                continue; // Allow negative sign at the beginning
            }
            
            if (c == '.' && !decimalFound) {
                decimalFound = true;
                continue; // Allow one decimal point
            }
            
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        
        return true;
    }

    private static void addEmployees() {
        int numEmployees = 0;
        boolean validInput = false;
        
        // Get number of employees with validation
        while (!validInput) {
            System.out.print("\nHow many employees do you want to enter? ");
            String input = scanner.nextLine().trim();
            
            if (isValidInteger(input)) {
                numEmployees = Integer.parseInt(input);
                
                if (numEmployees <= 0) {
                    System.out.println("Please enter a positive number.");
                    continue;
                }
                
                validInput = true;
            } else {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }
        
        // Add each employee
        for (int i = 0; i < numEmployees; i++) {
            System.out.println("\nEnter details for Employee #" + (i + 1));
            addSingleEmployee();
        }
        
        // Show payroll after adding
        calculatePayroll();
    }

    private static void addSingleEmployee() {
        String name = "";
        int age = 0;
        double hourlyRates = 0;
        int hoursWorked = 0;
        
        // Get name
        while (true) {
            System.out.print("Name: ");
            name = scanner.nextLine().trim();
            if (!name.isEmpty()) {
                break;
            }
            System.out.println("Name cannot be empty. Please enter a valid name.");
        }
        
        // Get age with validation
        while (true) {
            System.out.print("Age: ");
            String input = scanner.nextLine().trim();
            
            if (isValidInteger(input)) {
                age = Integer.parseInt(input);
                
                if (age < 18 || age > 65) {
                    System.out.println("Age must be between 18 and 65. Please enter a valid age.");
                    continue;
                }
                
                break;
            } else {
                System.out.println("Invalid input. Please enter a valid number for age.");
            }
        }
        
        // Get hourly rate with validation
        while (true) {
            System.out.print("Hourly Rate: ");
            String input = scanner.nextLine().trim();
            
            if (isValidDouble(input)) {
                hourlyRates = Double.parseDouble(input);
                
                if (hourlyRates <= 0) {
                    System.out.println("Hourly rate must be greater than 0. Please enter a valid rate.");
                    continue;
                }
                
                break;
            } else {
                System.out.println("Invalid input. Please enter a valid number for hourly rate.");
            }
        }
        
        // Get hours worked with validation
        while (true) {
            System.out.print("Hours Worked: ");
            String input = scanner.nextLine().trim();
            
            if (isValidInteger(input)) {
                hoursWorked = Integer.parseInt(input);
                
                if (hoursWorked <= 0 || hoursWorked > 60) {
                    System.out.println("Hours worked must be between 1 and 60. Please enter valid hours.");
                    continue;
                }
                
                break;
            } else {
                System.out.println("Invalid input. Please enter a valid number for hours worked.");
            }
        }
        
        // Create and add the employee
        employees.add(new Employee( hourlyRates, hoursWorked,nextId++, name, age));
        System.out.println("Employee added successfully!");
    }

    private static void deleteEmployee() {
        if (employees.isEmpty()) {
            System.out.println("\nNo employees in the system to delete.");
            return;
        }
        
        showReports(); // Show current employees
        
        boolean validInput = false;
        while (!validInput) {
            System.out.print("\nEnter the ID of the employee you want to delete(Position of employee on the list): ");
            String input = scanner.nextLine().trim();
            
            if (isValidInteger(input)) {
                int idToDelete = Integer.parseInt(input);
                
                boolean found = false;
                for (int i = 0; i < employees.size(); i++) {
                    if (employees.get(i).getId() == idToDelete) {
                        employees.remove(i);
                        System.out.println("Employee with ID " + idToDelete + " has been deleted.");
                        found = true;
                        break;
                    }
                }
                
                if (!found) {
                    System.out.println("No employee found with ID " + idToDelete + ". Please try again.");
                    continue;
                }
                
                validInput = true;
            } else {
                System.out.println("Invalid input. Please enter a valid employee ID.");
            }
        }
    }

    private static void showReports() {
        if (employees.isEmpty()) {
            System.out.println("\nNo employees in the system to display.");
            return;
        }
        
        System.out.println("\n=== Employee Reports ===");
        for (Employee emp : employees) {
            System.out.println(emp.getReport());
        }
    }

    private static void calculatePayroll() {
        if (employees.isEmpty()) {
            System.out.println("\nNo employees in the system to calculate payroll.");
            return;
        }
        
        double totalPayroll = 0;
        for (Employee emp : employees) {
            totalPayroll += emp.calculateSalary();
        }
        
        System.out.println("\n=== Payroll Calculation ===");
        System.out.printf("Total payroll for %d employees: $%.2f%n", employees.size(), totalPayroll);//(OpenAI.2023)
        
        // Show individual reports
        showReports();
    }
}
        
        
        
        
        
        
        
        
        
        
        
        
   
    


