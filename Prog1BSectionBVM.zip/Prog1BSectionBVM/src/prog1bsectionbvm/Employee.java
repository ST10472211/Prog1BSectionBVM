
package prog1bsectionbvm;


public class Employee extends Person{
    
    
    private double hourlyRates;
    private int hoursWorked;
    private int id;
    
    
    //constructor
    public Employee(double hourlyRates, int hoursWorked, int id, String name, int age) {
        super(name, age);
        this.hourlyRates = hourlyRates;
        this.hoursWorked = hoursWorked;
        this.id = id;
    }
    
    
    //Salary calculation
    public double calculateSalary(){
    return hourlyRates * hoursWorked;
    }
    
    //The report of employee payroll
    public String getReport(){
    
        return "Name:"
                 + getName()+ " , " + " Age:"
                + getAge()+ " , " + " Hours Worked:"
                + hoursWorked + " , " + "Rate per hour:"
                + hourlyRates + " , "
                +"Salary:"
                + calculateSalary()+" . ";
    
    }
    
    

 public int getId() {
        return id;
    }

    public double getHourlyRate() {
        return hourlyRates;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }
    
}